from django.shortcuts import render
from .models import *
from .forms import *
import math 
import os
from django.conf import settings
import cmath
import numpy as np

def epsp(request):
    return render(request, 'epsp.html', context={})


def pol2cart(rho, phi):
    x = rho * np.cos(phi)
    y = rho * np.sin(phi)
    return(x, y)

def mulComplex( z1, z2):
    return z1*z2
   

def epsppost(request):
    print(request.POST)
    if request.method=="POST":
        avoltage=request.POST['avoltage']
        acurrent=request.POST['acurrent']
        bvoltage=request.POST['bvoltage']
        bcurrent=request.POST['bcurrent']
        cvoltage=request.POST['cvoltage']
        ccurrent=request.POST['ccurrent']
        avoltage_mag = int(avoltage.split('<')[0])
        avoltage_phase = int(avoltage.split('<')[1])
        bvoltage_mag = int(bvoltage.split('<')[0])
        bvoltage_phase = int(bvoltage.split('<')[1])
        cvoltage_mag = int(cvoltage.split('<')[0])
        cvoltage_phase = int(avoltage.split('<')[1])
        acurrent_mag = int(acurrent.split('<')[0])
        acurrent_phase = int(acurrent.split('<')[1])
        bcurrent_mag = int(bcurrent.split('<')[0])
        bcurrent_phase = int(bcurrent.split('<')[1])
        ccurrent_mag = int(ccurrent.split('<')[0])
        ccurrent_phase = int(ccurrent.split('<')[1])
        # polar to cart
        avoltage_mag_cart = pol2cart(avoltage_mag,avoltage_phase)[0]
        avoltage_phase_cart = pol2cart(avoltage_mag,avoltage_phase)[1]
        bvoltage_mag_cart =pol2cart(bvoltage_mag,bvoltage_phase)[0]
        bvoltage_phase_cart = pol2cart(bvoltage_mag,bvoltage_phase)[1]
        cvoltage_mag_cart = pol2cart(cvoltage_mag,cvoltage_phase)[0]
        cvoltage_phase_cart = pol2cart(cvoltage_mag,cvoltage_phase)[1]
        acurrent_mag_cart = pol2cart(acurrent_mag,acurrent_phase)[0]
        acurrent_phase_cart = pol2cart(acurrent_mag,acurrent_phase)[1]
        bcurrent_mag_cart = pol2cart(bcurrent_mag,bcurrent_phase)[0]
        bcurrent_phase_cart = pol2cart(bcurrent_mag,bcurrent_phase)[1]
        ccurrent_mag_cart =  pol2cart(ccurrent_mag,ccurrent_phase)[0]
        ccurrent_phase_cart =  pol2cart(ccurrent_mag,ccurrent_phase)[1]
        # sequence components
        a = complex(-0.5,0.866)
        a_sq = mulComplex(complex(-0.5,0.866),complex(-0.5,0.866))
        v_zero_real =  math.floor((1/3)*(complex(avoltage_mag_cart,avoltage_phase_cart)+ complex(bvoltage_mag_cart,bvoltage_phase_cart)+complex(cvoltage_mag_cart,cvoltage_phase_cart)).real)
        v_zero_imag =  math.floor((1/3)*(complex(avoltage_mag_cart,avoltage_phase_cart)+ complex(bvoltage_mag_cart,bvoltage_phase_cart)+complex(cvoltage_mag_cart,cvoltage_phase_cart)).imag)
        
        v_positive_real =  math.floor((1/3)*(complex(avoltage_mag_cart,avoltage_phase_cart)+ mulComplex(a,complex(bvoltage_mag_cart,bvoltage_phase_cart))+mulComplex(a_sq,complex(cvoltage_mag_cart,cvoltage_phase_cart))).real)
        v_positive_imag =  math.floor((1/3)*(complex(avoltage_mag_cart,avoltage_phase_cart)+ mulComplex(a,complex(bvoltage_mag_cart,bvoltage_phase_cart))+mulComplex(a_sq,complex(cvoltage_mag_cart,cvoltage_phase_cart))).imag)
        
        v_negative_real =  math.floor((1/3)*(complex(avoltage_mag_cart,avoltage_phase_cart)+ mulComplex(a_sq,complex(bvoltage_mag_cart,bvoltage_phase_cart))+mulComplex(a,complex(cvoltage_mag_cart,cvoltage_phase_cart))).real)
        v_negative_imag =  math.floor((1/3)*(complex(avoltage_mag_cart,avoltage_phase_cart)+ mulComplex(a_sq,complex(bvoltage_mag_cart,bvoltage_phase_cart))+mulComplex(a,complex(cvoltage_mag_cart,cvoltage_phase_cart))).imag)
        
        # print(v_positive_real)
        # print(v_negative_real)
        # print(v_zero_real)

        i_zero_real =  math.floor((1/3)*(complex(acurrent_mag_cart,acurrent_phase_cart)+ complex(bcurrent_mag_cart,bcurrent_phase_cart)+complex(ccurrent_mag_cart,ccurrent_phase_cart)).real)
        i_zero_imag =  math.floor((1/3)*(complex(acurrent_mag_cart,acurrent_phase_cart)+ complex(bcurrent_mag_cart,bcurrent_phase_cart)+complex(ccurrent_mag_cart,ccurrent_phase_cart)).imag)
        
        i_positive_real =  math.floor((1/3)*(complex(acurrent_mag_cart,acurrent_phase_cart)+ mulComplex(a,complex(bcurrent_mag_cart,bcurrent_phase_cart))+mulComplex(a_sq,complex(ccurrent_mag_cart,ccurrent_phase_cart))).real)
        i_positive_imag =  math.floor((1/3)*(complex(acurrent_mag_cart,acurrent_phase_cart)+ mulComplex(a,complex(bcurrent_mag_cart,bcurrent_phase_cart))+mulComplex(a_sq,complex(ccurrent_mag_cart,ccurrent_phase_cart))).imag)
        
        i_negative_real =  math.floor((1/3)*(complex(acurrent_mag_cart,acurrent_phase_cart)+ mulComplex(a_sq,complex(bcurrent_mag_cart,bcurrent_phase_cart))+mulComplex(a,complex(ccurrent_mag_cart,ccurrent_phase_cart))).real)
        i_negative_imag =  math.floor((1/3)*(complex(acurrent_mag_cart,acurrent_phase_cart)+ mulComplex(a_sq,complex(bcurrent_mag_cart,bcurrent_phase_cart))+mulComplex(a,complex(ccurrent_mag_cart,ccurrent_phase_cart))).imag)
        # print(i_positive_real)
        # print(i_negative_real)
        # print(i_zero_real)
        # print(i_positive_imag)
        # print(i_negative_imag)
        # print(i_zero_imag)
        
        result = None
        print(avoltage_mag == bvoltage_mag == cvoltage_mag)
        if (complex(v_zero_real,v_zero_imag) == complex(0,0)) and (avoltage_mag == bvoltage_mag == cvoltage_mag) and (abs(int(avoltage_phase) - int(bvoltage_phase)) == abs(int(bvoltage_phase) - int(cvoltage_phase))):
            result = "3 phase fault detected"
            print("3 phase fault detected")
        elif (complex(i_zero_real,i_zero_real) == complex(i_positive_real,i_positive_real) == complex(i_negative_real,i_negative_real)):
            result = "Single line to ground fault detected"
            print("Single line to ground fault detected")
        elif (complex(i_zero_real,i_zero_real) + complex(i_positive_real,i_positive_real) + complex(i_negative_real,i_negative_real)) == complex(0,0):
            result = "Double line to ground fault detected"
            print("Double line to ground fault detected")
        elif (complex(i_zero_real,i_zero_imag) == complex(0,0)) and (complex(abs(i_positive_real),abs(i_positive_real)) == complex(abs(i_negative_real),abs(i_negative_real)))  :
            result = "Line to line fault detected"
            print("Line to line fault detected")
        else:
            result = "Invalid Fault Phasors"
            print("Invalid Fault Phasors")
        # complex(2, 3)
    return render(request, 'epsppost.html', context={ 'result': result})
