from django.conf.urls import url,include
from django.contrib import admin
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    url(r'^$', views.epsp  , name='index'),
    url(r'^epsp$', views.epsp  , name='epsp'),
    url(r'^epsppost$', views.epsppost  , name='epsppost'),
    
]

admin.site.site_header = 'EPT CEP'
admin.site.index_title = 'EPT CEP'              
admin.site.site_title = 'EPT CEP'


urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)